var Config = {
    wsUrl: "ws://172.24.1.1:8181/core"
};
