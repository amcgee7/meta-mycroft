from os.path import abspath, dirname, join

__author__ = 'seanfitz'

MYCROFT_ROOT_PATH = abspath(join(dirname(__file__), '..'))
