import unittest

from mycroft.skills.pairing import PairingSkill


class PairingSkillTest(unittest.TestCase):
    skill = PairingSkill()
